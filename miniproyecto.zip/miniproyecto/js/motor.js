var posicion=0
document.getElementById("foto").src= personas[posicion].foto
document.getElementById("nombre").innerHTML= personas[posicion].nombre
document.getElementById("fecha").innerHTML= personas[posicion].fecha
document.getElementById("descripcion").innerHTML= personas[posicion].descripcion
document.getElementById("centro").innerHTML= personas[posicion].centro


function siguiente(){

posicion++;
document.getElementById("foto").src= personas[posicion].foto
document.getElementById("nombre").innerHTML= personas[posicion].nombre
document.getElementById("fecha").innerHTML= personas[posicion].fecha
document.getElementById("descripcion").innerHTML= personas[posicion].descripcion
document.getElementById("centro").innerHTML= personas[posicion].centro


}
function atras(){

    posicion--;
    document.getElementById("foto").src= personas[posicion].foto
    document.getElementById("nombre").innerHTML= personas[posicion].nombre
    document.getElementById("fecha").innerHTML= personas[posicion].fecha
    document.getElementById("descripcion").innerHTML= personas[posicion].descripcion
    document.getElementById("centro").innerHTML= personas[posicion].centro
    
    
    
    }
