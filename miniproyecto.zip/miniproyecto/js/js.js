var personas= new Array(

    {
    
    foto:"img/ESO.jpg",
    nombre:"ESO",
    fecha:"2010-2014",
    descripcion:"certificado de ESO",
    centro:"Nuestra señora de la merced",
  
    },
    {
    
        foto:"img/Bachillerato.png",
        nombre:"Bachillerato",
        fecha:"2014-2017",
        descripcion:"certificado de bachillerato en Artes ",
        centro:"Instituto Guzman",
      
        },
        {
    
            foto:"img/DAM.png",
            nombre:"Grado superior DAM",
            fecha:"2017-2019",
            descripcion:"certificado en DAM",
            centro:"Ifp Madrid",
           
            },
            {
    
                foto:"img/DAW.jpg",
                nombre:"Grado superior DAW",
                fecha:"2019-2020",
                descripcion:" futuro certificado en DAW",
                centro:"IES Tetuan",

              
                },
    
    
    
    );